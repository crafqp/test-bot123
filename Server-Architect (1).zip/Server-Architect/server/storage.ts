// Storage interface for Discord Bot Builder
// Currently using in-memory storage for session management

export interface IStorage {
  // Placeholder for future persistence needs
}

export class MemStorage implements IStorage {
  constructor() {}
}

export const storage = new MemStorage();
