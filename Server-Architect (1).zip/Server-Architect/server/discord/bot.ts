// Discord Server Builder Bot
// Uses Discord.js integration from Replit connector

import {
  Client,
  GatewayIntentBits,
  Events,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  PermissionFlagsBits,
  Partials,
  type Guild,
  type TextChannel,
  type Interaction,
  type Message,
  type GuildMember,
  type ButtonInteraction,
  type StringSelectMenuInteraction,
  type ModalSubmitInteraction,
  ColorResolvable,
  PermissionsBitField,
} from "discord.js";

import {
  generateServerDesign,
  processModificationRequest,
  analyzeServerPurpose,
  generateChannelTopics,
  generateWelcomeMessage,
  generateServerRules,
  type ServerDesign,
  type QuestionnaireResponses,
  type CategoryConfig,
  type ChannelConfig,
  type RoleConfig,
} from "../gemini";

// Discord color constants
const COLORS = {
  BLURPLE: 0x5865f2,
  GREEN: 0x57f287,
  YELLOW: 0xfee75c,
  RED: 0xed4245,
  GRAY: 0x99aab5,
  WHITE: 0xffffff,
};

// Active questionnaire sessions
const activeSessions = new Map<
  string,
  {
    guildId: string;
    userId: string;
    channelId: string;
    responses: Partial<QuestionnaireResponses>;
    currentQuestion: number;
    design?: ServerDesign;
  }
>();

// Server templates for quick setup
const SERVER_TEMPLATES = {
  gaming: {
    name: "Gaming Community",
    description: "Perfect for gaming communities, streamers, and esports teams",
    responses: {
      serverPurpose: "Gaming community for players to connect, team up, and discuss games",
      targetAudience: "teens",
      communitySize: "medium",
      primaryActivities: ["gaming", "voice", "chat"],
      channelTypes: ["welcome", "announcements", "general", "voice", "media", "bots"],
      roleHierarchy: "Owner, Admins, Moderators, VIP, Members, New Players",
      moderationLevel: "moderate",
      designTheme: "gaming",
      colorPreferences: "Vibrant gaming colors - purple, cyan, green",
      emojiStyle: "colorful",
      namingStyle: "casual",
      ticketSystemNeeded: true,
      specialFeatures: ["welcome_msg", "reaction_roles", "levels"],
      accessLevels: "open",
      additionalNotes: "Include LFG channels and game-specific channels",
    },
  },
  business: {
    name: "Business/Professional",
    description: "Ideal for companies, startups, and professional teams",
    responses: {
      serverPurpose: "Professional workspace for team collaboration and communication",
      targetAudience: "professional",
      communitySize: "small",
      primaryActivities: ["chat", "voice", "collab", "events"],
      channelTypes: ["announcements", "general", "feedback", "help"],
      roleHierarchy: "Leadership, Department Heads, Managers, Team Members, Guests",
      moderationLevel: "strict",
      designTheme: "professional",
      colorPreferences: "Clean professional colors - navy blue, gray, white",
      emojiStyle: "minimal",
      namingStyle: "technical",
      ticketSystemNeeded: true,
      specialFeatures: ["welcome_msg", "logging", "verification"],
      accessLevels: "verified",
      additionalNotes: "Organized by departments with clear separation",
    },
  },
  community: {
    name: "General Community",
    description: "Great for friend groups, hobby communities, and social spaces",
    responses: {
      serverPurpose: "Friendly community space for people to hang out and connect",
      targetAudience: "general",
      communitySize: "medium",
      primaryActivities: ["chat", "voice", "content", "events"],
      channelTypes: ["welcome", "announcements", "general", "offtopic", "media", "voice", "intros"],
      roleHierarchy: "Admin, Moderators, Regulars, Members, Newcomers",
      moderationLevel: "moderate",
      designTheme: "community",
      colorPreferences: "Warm, friendly colors - orange, yellow, soft blue",
      emojiStyle: "unicode",
      namingStyle: "lowercase",
      ticketSystemNeeded: false,
      specialFeatures: ["welcome_msg", "autorole", "reaction_roles"],
      accessLevels: "open",
      additionalNotes: "Focus on social interaction and fun",
    },
  },
  education: {
    name: "Educational/Study Group",
    description: "Perfect for study groups, courses, and learning communities",
    responses: {
      serverPurpose: "Educational space for learning, studying, and knowledge sharing",
      targetAudience: "students",
      communitySize: "medium",
      primaryActivities: ["education", "chat", "voice", "collab"],
      channelTypes: ["welcome", "announcements", "general", "help", "feedback"],
      roleHierarchy: "Instructors, Teaching Assistants, Senior Students, Students, Newcomers",
      moderationLevel: "moderate",
      designTheme: "educational",
      colorPreferences: "Academic colors - deep blue, green, gold",
      emojiStyle: "unicode",
      namingStyle: "titlecase",
      ticketSystemNeeded: true,
      specialFeatures: ["welcome_msg", "logging", "events"],
      accessLevels: "tiered",
      additionalNotes: "Include subject-specific channels and study session voice channels",
    },
  },
  creative: {
    name: "Creative/Artist Community",
    description: "For artists, designers, writers, and creative individuals",
    responses: {
      serverPurpose: "Creative community for artists to share work and collaborate",
      targetAudience: "niche",
      communitySize: "medium",
      primaryActivities: ["content", "chat", "collab", "events"],
      channelTypes: ["welcome", "announcements", "general", "media", "feedback", "voice"],
      roleHierarchy: "Curators, Featured Artists, Verified Artists, Members, Observers",
      moderationLevel: "light",
      designTheme: "creative",
      colorPreferences: "Artistic palette - pastel colors, gradient-inspired",
      emojiStyle: "themed",
      namingStyle: "casual",
      ticketSystemNeeded: false,
      specialFeatures: ["welcome_msg", "reaction_roles", "starboard"],
      accessLevels: "open",
      additionalNotes: "Gallery channels for different art types, critique and feedback sections",
    },
  },
};

// Reaction role configurations stored per guild
const reactionRoleConfigs = new Map<string, ReactionRoleConfig[]>();

interface ReactionRoleConfig {
  messageId: string;
  channelId: string;
  emoji: string;
  roleId: string;
  roleName: string;
}

// Welcome message configurations per guild
const welcomeConfigs = new Map<string, WelcomeConfig>();

interface WelcomeConfig {
  channelId: string;
  message: string;
  autoRoleId?: string;
  autoRoleName?: string;
}

// Permission mapping
const PERMISSION_MAP: Record<string, bigint> = {
  ViewChannel: PermissionFlagsBits.ViewChannel,
  SendMessages: PermissionFlagsBits.SendMessages,
  ManageMessages: PermissionFlagsBits.ManageMessages,
  ManageChannels: PermissionFlagsBits.ManageChannels,
  ManageRoles: PermissionFlagsBits.ManageRoles,
  ManageGuild: PermissionFlagsBits.ManageGuild,
  KickMembers: PermissionFlagsBits.KickMembers,
  BanMembers: PermissionFlagsBits.BanMembers,
  MuteMembers: PermissionFlagsBits.MuteMembers,
  DeafenMembers: PermissionFlagsBits.DeafenMembers,
  MoveMembers: PermissionFlagsBits.MoveMembers,
  Connect: PermissionFlagsBits.Connect,
  Speak: PermissionFlagsBits.Speak,
  Stream: PermissionFlagsBits.Stream,
  EmbedLinks: PermissionFlagsBits.EmbedLinks,
  AttachFiles: PermissionFlagsBits.AttachFiles,
  ReadMessageHistory: PermissionFlagsBits.ReadMessageHistory,
  MentionEveryone: PermissionFlagsBits.MentionEveryone,
  UseExternalEmojis: PermissionFlagsBits.UseExternalEmojis,
  AddReactions: PermissionFlagsBits.AddReactions,
  CreateInstantInvite: PermissionFlagsBits.CreateInstantInvite,
  Administrator: PermissionFlagsBits.Administrator,
  ModerateMembers: PermissionFlagsBits.ModerateMembers,
};

// Questions for the deep questionnaire
const QUESTIONS = [
  {
    id: "purpose",
    title: "What is the main purpose of your server?",
    description:
      "This helps us understand what kind of server structure and features you need.",
    type: "text",
    placeholder: "E.g., Gaming community, Study group, Business team, Creative collective...",
  },
  {
    id: "audience",
    title: "Who is your target audience?",
    description: "Understanding your audience helps us set appropriate permissions and tone.",
    type: "select",
    options: [
      { label: "General Public (All ages)", value: "general" },
      { label: "Adults (18+)", value: "adults" },
      { label: "Teens & Young Adults", value: "teens" },
      { label: "Professionals/Business", value: "professional" },
      { label: "Students/Academics", value: "students" },
      { label: "Specific Interest Group", value: "niche" },
    ],
  },
  {
    id: "size",
    title: "What community size are you expecting?",
    description: "This affects how we structure roles, channels, and moderation.",
    type: "select",
    options: [
      { label: "Small (Under 50 members)", value: "small" },
      { label: "Medium (50-500 members)", value: "medium" },
      { label: "Large (500-5000 members)", value: "large" },
      { label: "Very Large (5000+ members)", value: "xlarge" },
    ],
  },
  {
    id: "activities",
    title: "What primary activities will happen in your server?",
    description: "Select all that apply. This determines what channel types we create.",
    type: "multiselect",
    options: [
      { label: "Text Chat & Discussions", value: "chat" },
      { label: "Voice Calls & Hangouts", value: "voice" },
      { label: "Gaming Together", value: "gaming" },
      { label: "Content Sharing (Art, Music, Videos)", value: "content" },
      { label: "Learning & Education", value: "education" },
      { label: "Events & Announcements", value: "events" },
      { label: "Support & Help Desk", value: "support" },
      { label: "Collaboration & Projects", value: "collab" },
    ],
  },
  {
    id: "channels",
    title: "What types of channels do you want?",
    description: "Select the channel types that fit your community needs.",
    type: "multiselect",
    options: [
      { label: "Welcome & Rules", value: "welcome" },
      { label: "Announcements", value: "announcements" },
      { label: "General Chat", value: "general" },
      { label: "Off-Topic/Casual", value: "offtopic" },
      { label: "Media/Content Sharing", value: "media" },
      { label: "Voice Channels", value: "voice" },
      { label: "Help/Support", value: "help" },
      { label: "Feedback/Suggestions", value: "feedback" },
      { label: "Introductions", value: "intros" },
      { label: "Bot Commands", value: "bots" },
    ],
  },
  {
    id: "roles",
    title: "Describe your ideal role hierarchy",
    description: "Tell us about the different member levels and staff positions you need.",
    type: "text",
    placeholder:
      "E.g., Owner, Admins, Moderators, VIP Members, Regular Members, New Members...",
  },
  {
    id: "moderation",
    title: "What level of moderation do you need?",
    description: "This determines moderation tools and auto-mod settings.",
    type: "select",
    options: [
      { label: "Light - Trust the community", value: "light" },
      { label: "Moderate - Standard moderation", value: "moderate" },
      { label: "Strict - Heavy moderation needed", value: "strict" },
      { label: "Maximum - Full control required", value: "maximum" },
    ],
  },
  {
    id: "theme",
    title: "What design theme fits your server?",
    description: "This affects colors, naming style, and overall visual feel.",
    type: "select",
    options: [
      { label: "Professional & Clean", value: "professional" },
      { label: "Gaming & Vibrant", value: "gaming" },
      { label: "Creative & Artistic", value: "creative" },
      { label: "Educational & Organized", value: "educational" },
      { label: "Community & Friendly", value: "community" },
      { label: "Dark & Minimal", value: "dark" },
      { label: "Bright & Colorful", value: "bright" },
    ],
  },
  {
    id: "colors",
    title: "What color preferences do you have?",
    description: "Describe colors you like or specific brand colors to use.",
    type: "text",
    placeholder: "E.g., Blue and white, Dark purple theme, Our brand color is #FF5500...",
  },
  {
    id: "emojis",
    title: "What emoji style do you prefer?",
    description: "This affects category and channel prefixes.",
    type: "select",
    options: [
      { label: "Minimal - Few or no emojis", value: "minimal" },
      { label: "Unicode - Standard emojis only", value: "unicode" },
      { label: "Colorful - Lots of varied emojis", value: "colorful" },
      { label: "Themed - Matching a specific theme", value: "themed" },
    ],
  },
  {
    id: "naming",
    title: "How should channels be named?",
    description: "Choose a naming convention for your channels.",
    type: "select",
    options: [
      { label: "lowercase-with-dashes", value: "lowercase" },
      { label: "Title Case With Spaces (where allowed)", value: "titlecase" },
      { label: "friendly-casual-names", value: "casual" },
      { label: "Organized-With-Prefixes", value: "technical" },
    ],
  },
  {
    id: "tickets",
    title: "Do you need a ticket/support system?",
    description: "For handling user requests, reports, or support privately.",
    type: "buttons",
    options: [
      { label: "Yes, I need tickets", value: "yes", style: ButtonStyle.Success },
      { label: "No tickets needed", value: "no", style: ButtonStyle.Secondary },
      { label: "Maybe later", value: "maybe", style: ButtonStyle.Secondary },
    ],
  },
  {
    id: "features",
    title: "What special features would you like?",
    description: "Select any additional features you want.",
    type: "multiselect",
    options: [
      { label: "Welcome Messages for New Members", value: "welcome_msg" },
      { label: "Auto-Role Assignment", value: "autorole" },
      { label: "Reaction Roles", value: "reaction_roles" },
      { label: "Level/XP System Ready", value: "levels" },
      { label: "Event Channels", value: "events" },
      { label: "Logging/Audit Channels", value: "logging" },
      { label: "Verification System", value: "verification" },
      { label: "Starboard/Highlights", value: "starboard" },
    ],
  },
  {
    id: "access",
    title: "How should member access work?",
    description: "Define who can see and do what.",
    type: "select",
    options: [
      { label: "Open - Everyone sees everything", value: "open" },
      { label: "Tiered - Different levels unlock more", value: "tiered" },
      { label: "Verified - Must verify to access", value: "verified" },
      { label: "Private - Invite/approval only", value: "private" },
    ],
  },
  {
    id: "notes",
    title: "Any additional notes or specific requests?",
    description: "Tell us anything else you want for your server.",
    type: "text",
    placeholder: "E.g., I want a specific channel for X, or please include Y feature...",
  },
];

// Create and start the Discord bot
export async function createDiscordBot(): Promise<Client> {
  const token = process.env.DISCORD_BOT_TOKEN;

  if (!token) {
    throw new Error("DISCORD_BOT_TOKEN environment variable is not set");
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMessageReactions,
    ],
    partials: [
      Partials.Message,
      Partials.Channel,
      Partials.Reaction,
    ],
  });

  // Bot ready event
  client.once(Events.ClientReady, (readyClient) => {
    console.log(`Discord bot ready! Logged in as ${readyClient.user.tag}`);
    console.log(`Serving ${readyClient.guilds.cache.size} guilds`);
  });

  // Guild join event - start setup process
  client.on(Events.GuildCreate, async (guild) => {
    console.log(`Joined new guild: ${guild.name} (${guild.id})`);
    await sendWelcomeMessage(guild);
  });

  // Message handler for commands
  client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot) return;

    const content = message.content.toLowerCase().trim();

    // Setup command
    if (content === "!setup" || content === "/setup") {
      await startQuestionnaire(message);
    }

    // Templates command
    if (content === "!templates" || content === "/templates") {
      await showTemplates(message);
    }

    // Modify command
    if (content.startsWith("!modify ") || content.startsWith("/modify ")) {
      const request = message.content.slice(8).trim();
      await handleModificationRequest(message, request);
    }

    // Help command
    if (content === "!help" || content === "/help") {
      await sendHelpMessage(message);
    }

    // Preview command - show current design if in session
    if (content === "!preview" || content === "/preview") {
      await showCurrentPreview(message);
    }

    // Reaction roles setup command
    if (content === "!reactionroles" || content === "/reactionroles") {
      await startReactionRoleSetup(message);
    }

    // Welcome setup command
    if (content === "!welcome" || content === "/welcome") {
      await showWelcomeSetup(message);
    }
  });

  // Handle new member joins for welcome messages and auto-roles
  client.on(Events.GuildMemberAdd, async (member) => {
    const config = welcomeConfigs.get(member.guild.id);
    if (!config) return;

    try {
      // Send welcome message
      const channel = member.guild.channels.cache.get(config.channelId) as TextChannel;
      if (channel) {
        const welcomeEmbed = new EmbedBuilder()
          .setColor(COLORS.GREEN)
          .setTitle(`Welcome to ${member.guild.name}!`)
          .setDescription(config.message.replace("{user}", `${member}`).replace("{server}", member.guild.name))
          .setThumbnail(member.user.displayAvatarURL())
          .setTimestamp()
          .setFooter({ text: `Member #${member.guild.memberCount}` });

        await channel.send({ embeds: [welcomeEmbed] });
      }

      // Assign auto-role if configured
      if (config.autoRoleId) {
        const role = member.guild.roles.cache.get(config.autoRoleId);
        if (role) {
          await member.roles.add(role, "Auto-role assignment on join");
        }
      }
    } catch (error) {
      console.error("Welcome message/auto-role error:", error);
    }
  });

  // Handle reaction add for reaction roles
  client.on(Events.MessageReactionAdd, async (reaction, user) => {
    if (user.bot) return;

    // Fetch partial reaction/message if needed
    if (reaction.partial) {
      try {
        await reaction.fetch();
      } catch (error) {
        console.error("Failed to fetch partial reaction:", error);
        return;
      }
    }

    const guildConfigs = reactionRoleConfigs.get(reaction.message.guildId!);
    if (!guildConfigs) return;

    const config = guildConfigs.find(
      (c) => c.messageId === reaction.message.id && c.emoji === reaction.emoji.name
    );
    if (!config) return;

    try {
      const guild = reaction.message.guild;
      if (!guild) return;

      const member = await guild.members.fetch(user.id);
      const role = guild.roles.cache.get(config.roleId);

      if (role && member) {
        await member.roles.add(role, "Reaction role assignment");
      }
    } catch (error) {
      console.error("Reaction role add error:", error);
    }
  });

  // Handle reaction remove for reaction roles
  client.on(Events.MessageReactionRemove, async (reaction, user) => {
    if (user.bot) return;

    // Fetch partial reaction/message if needed
    if (reaction.partial) {
      try {
        await reaction.fetch();
      } catch (error) {
        console.error("Failed to fetch partial reaction:", error);
        return;
      }
    }

    const guildConfigs = reactionRoleConfigs.get(reaction.message.guildId!);
    if (!guildConfigs) return;

    const config = guildConfigs.find(
      (c) => c.messageId === reaction.message.id && c.emoji === reaction.emoji.name
    );
    if (!config) return;

    try {
      const guild = reaction.message.guild;
      if (!guild) return;

      const member = await guild.members.fetch(user.id);
      const role = guild.roles.cache.get(config.roleId);

      if (role && member) {
        await member.roles.remove(role, "Reaction role removal");
      }
    } catch (error) {
      console.error("Reaction role remove error:", error);
    }
  });

  // Interaction handler for buttons, selects, and modals
  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      if (interaction.isButton()) {
        await handleButtonInteraction(interaction);
      } else if (interaction.isStringSelectMenu()) {
        await handleSelectInteraction(interaction);
      } else if (interaction.isModalSubmit()) {
        await handleModalSubmit(interaction);
      }
    } catch (error) {
      console.error("Interaction error:", error);
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: "An error occurred processing your request. Please try again.",
          ephemeral: true,
        });
      }
    }
  });

  await client.login(token);
  return client;
}

async function sendWelcomeMessage(guild: Guild) {
  // Find a suitable channel to send the welcome message
  const systemChannel = guild.systemChannel;
  const defaultChannel = guild.channels.cache.find(
    (ch) =>
      ch.type === ChannelType.GuildText &&
      ch.permissionsFor(guild.members.me!)?.has(PermissionFlagsBits.SendMessages)
  ) as TextChannel | undefined;

  const channel = systemChannel || defaultChannel;
  if (!channel) return;

  const embed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Server Builder Bot")
    .setDescription(
      `Thanks for adding me to **${guild.name}**!\n\nI can help you create a professional, fully-configured Discord server with intelligent permissions, organized channels, and functional systems.\n\n**To get started, type \`!setup\` or \`/setup\`**`
    )
    .addFields(
      {
        name: "What I Can Do",
        value:
          "- Create organized categories & channels\n- Set up intelligent permissions\n- Configure roles with proper hierarchy\n- Build a ticket/support system\n- Set up moderation tools\n- Apply your preferred design theme",
      },
      {
        name: "Commands",
        value:
          "`!setup` - Start the server setup questionnaire\n`!modify <request>` - Make changes after setup\n`!help` - Show this help message",
      }
    )
    .setFooter({ text: "Powered by Gemini AI" });

  const button = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("start_setup")
      .setLabel("Start Setup")
      .setStyle(ButtonStyle.Primary)
  );

  await channel.send({ embeds: [embed], components: [button] });
}

async function sendHelpMessage(message: Message) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.GRAY)
    .setTitle("Server Builder Bot - Help")
    .setDescription("I help you create professional Discord servers with AI-powered design.")
    .addFields(
      {
        name: "Setup Commands",
        value:
          "`!setup` - Start the full setup questionnaire (15+ questions)\n`!templates` - Quick setup using pre-made templates\n`!preview` - View current server design before applying",
      },
      {
        name: "Feature Commands",
        value:
          "`!welcome` - Configure welcome messages & auto-roles\n`!reactionroles` - Set up reaction-based role assignment\n`!modify <request>` - Make changes using natural language",
      },
      {
        name: "How It Works",
        value:
          "1. Choose full setup or use a template\n2. Answer questions about your server preferences\n3. Review the AI-generated server design\n4. Confirm to apply changes\n5. Use additional commands to add features",
      },
      {
        name: "Features",
        value:
          "- Intelligent channel & category organization\n- Role hierarchy with proper permissions\n- Themed design (colors, emojis, naming)\n- Ticket/support system\n- Welcome messages & auto-roles\n- Reaction roles\n- Moderation tools & logging",
      }
    )
    .setFooter({ text: "Powered by Gemini AI" });

  await message.reply({ embeds: [embed] });
}

async function showTemplates(message: Message) {
  if (!message.guild) return;

  const member = message.member as GuildMember;
  if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
    await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.RED)
          .setTitle("Permission Denied")
          .setDescription("You need Administrator permissions to use templates."),
      ],
    });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Server Templates")
    .setDescription("Choose a pre-made template for quick server setup. Each template comes with optimized channels, roles, and permissions.")
    .addFields(
      Object.entries(SERVER_TEMPLATES).map(([key, template]) => ({
        name: template.name,
        value: template.description,
        inline: false,
      }))
    )
    .setFooter({ text: "Select a template below to preview it" });

  const selectMenu = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`template_select_${message.guild.id}_${message.author.id}`)
      .setPlaceholder("Choose a template")
      .addOptions(
        Object.entries(SERVER_TEMPLATES).map(([key, template]) => ({
          label: template.name,
          value: key,
          description: template.description.substring(0, 50) + "...",
        }))
      )
  );

  await message.reply({ embeds: [embed], components: [selectMenu] });
}

async function showWelcomeSetup(message: Message) {
  if (!message.guild) return;

  const member = message.member as GuildMember;
  if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
    await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.RED)
          .setTitle("Permission Denied")
          .setDescription("You need Administrator permissions to configure welcome messages."),
      ],
    });
    return;
  }

  const currentConfig = welcomeConfigs.get(message.guild.id);

  const embed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Welcome System Setup")
    .setDescription(
      currentConfig
        ? `Current welcome channel: <#${currentConfig.channelId}>\nAuto-role: ${currentConfig.autoRoleName || "None"}`
        : "Set up welcome messages for new members and optionally assign a role when they join."
    )
    .addFields(
      {
        name: "Variables",
        value: "`{user}` - Mentions the new member\n`{server}` - Server name",
      }
    );

  const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`welcome_configure_${message.guild.id}`)
      .setLabel("Configure Welcome")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`welcome_disable_${message.guild.id}`)
      .setLabel("Disable")
      .setStyle(ButtonStyle.Danger)
      .setDisabled(!currentConfig)
  );

  await message.reply({ embeds: [embed], components: [buttons] });
}

async function startReactionRoleSetup(message: Message) {
  if (!message.guild) return;

  const member = message.member as GuildMember;
  if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
    await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.RED)
          .setTitle("Permission Denied")
          .setDescription("You need Administrator permissions to set up reaction roles."),
      ],
    });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Reaction Roles Setup")
    .setDescription(
      "I'll create a reaction role message where users can react to get roles.\n\n" +
      "Click the button below to configure your reaction roles. You'll be able to:\n" +
      "- Choose which roles to include\n- Customize the message title and description\n- Pick emojis for each role"
    );

  const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`rr_create_${message.guild.id}`)
      .setLabel("Create Reaction Roles")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`rr_view_${message.guild.id}`)
      .setLabel("View Existing")
      .setStyle(ButtonStyle.Secondary)
  );

  await message.reply({ embeds: [embed], components: [buttons] });
}

async function startQuestionnaire(message: Message) {
  if (!message.guild) return;

  // Check if user has admin permissions
  const member = message.member as GuildMember;
  if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
    await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.RED)
          .setTitle("Permission Denied")
          .setDescription("You need Administrator permissions to set up the server."),
      ],
    });
    return;
  }

  const sessionId = `${message.guild.id}-${message.author.id}`;

  // Initialize session
  activeSessions.set(sessionId, {
    guildId: message.guild.id,
    userId: message.author.id,
    channelId: message.channel.id,
    responses: {},
    currentQuestion: 0,
  });

  await sendQuestion(message.channel as TextChannel, sessionId, 0);
}

async function sendQuestion(channel: TextChannel, sessionId: string, questionIndex: number) {
  const session = activeSessions.get(sessionId);
  if (!session) return;

  const question = QUESTIONS[questionIndex];
  if (!question) return;

  const embed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle(question.title)
    .setDescription(question.description)
    .setFooter({ text: `Question ${questionIndex + 1} of ${QUESTIONS.length}` });

  let components: ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>[] = [];

  switch (question.type) {
    case "text":
      // For text questions, use a button to open modal
      components.push(
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder()
            .setCustomId(`open_modal_${question.id}_${sessionId}`)
            .setLabel("Answer")
            .setStyle(ButtonStyle.Primary)
        )
      );
      break;

    case "select":
      components.push(
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(`select_${question.id}_${sessionId}`)
            .setPlaceholder("Choose an option")
            .addOptions(
              question.options!.map((opt) => ({
                label: opt.label,
                value: opt.value,
              }))
            )
        )
      );
      break;

    case "multiselect":
      components.push(
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(`multiselect_${question.id}_${sessionId}`)
            .setPlaceholder("Select all that apply")
            .setMinValues(1)
            .setMaxValues(question.options!.length)
            .addOptions(
              question.options!.map((opt) => ({
                label: opt.label,
                value: opt.value,
              }))
            )
        )
      );
      break;

    case "buttons":
      components.push(
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          question.options!.map((opt) =>
            new ButtonBuilder()
              .setCustomId(`button_${question.id}_${opt.value}_${sessionId}`)
              .setLabel(opt.label)
              .setStyle(opt.style || ButtonStyle.Secondary)
          )
        )
      );
      break;
  }

  // Add skip button for optional questions
  if (questionIndex > 0) {
    const skipRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`skip_${question.id}_${sessionId}`)
        .setLabel("Skip")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`back_${question.id}_${sessionId}`)
        .setLabel("Back")
        .setStyle(ButtonStyle.Secondary)
    );
    components.push(skipRow);
  }

  await channel.send({ embeds: [embed], components });
}

async function handleButtonInteraction(interaction: ButtonInteraction) {
  const customId = interaction.customId;

  // Start setup button
  if (customId === "start_setup") {
    const message = interaction.message;
    if (!message.guild) return;

    const member = interaction.member as GuildMember;
    if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
      await interaction.reply({
        content: "You need Administrator permissions to set up the server.",
        ephemeral: true,
      });
      return;
    }

    const sessionId = `${message.guild.id}-${interaction.user.id}`;
    activeSessions.set(sessionId, {
      guildId: message.guild.id,
      userId: interaction.user.id,
      channelId: message.channel.id,
      responses: {},
      currentQuestion: 0,
    });

    await interaction.deferUpdate();
    await sendQuestion(message.channel as TextChannel, sessionId, 0);
    return;
  }

  // Open modal for text input
  if (customId.startsWith("open_modal_")) {
    const parts = customId.split("_");
    const questionId = parts[2];
    const sessionId = parts.slice(3).join("_");
    const question = QUESTIONS.find((q) => q.id === questionId);

    if (!question) return;

    const modal = new ModalBuilder()
      .setCustomId(`modal_${questionId}_${sessionId}`)
      .setTitle(question.title);

    const textInput = new TextInputBuilder()
      .setCustomId("response")
      .setLabel(question.title)
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder(question.placeholder || "Enter your response...")
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(textInput));

    await interaction.showModal(modal);
    return;
  }

  // Button choice answers
  if (customId.startsWith("button_")) {
    const parts = customId.split("_");
    const questionId = parts[1];
    const value = parts[2];
    const sessionId = parts.slice(3).join("_");

    await processAnswer(interaction, sessionId, questionId, value);
    return;
  }

  // Skip button
  if (customId.startsWith("skip_")) {
    const parts = customId.split("_");
    const questionId = parts[1];
    const sessionId = parts.slice(2).join("_");

    await processAnswer(interaction, sessionId, questionId, "");
    return;
  }

  // Back button
  if (customId.startsWith("back_")) {
    const parts = customId.split("_");
    const sessionId = parts.slice(2).join("_");
    const session = activeSessions.get(sessionId);

    if (session && session.currentQuestion > 0) {
      session.currentQuestion--;
      await interaction.deferUpdate();
      await sendQuestion(interaction.channel as TextChannel, sessionId, session.currentQuestion);
    }
    return;
  }

  // Confirm server creation
  if (customId.startsWith("confirm_create_")) {
    const sessionId = customId.replace("confirm_create_", "");
    await executeServerCreation(interaction, sessionId);
    return;
  }

  // Cancel server creation
  if (customId.startsWith("cancel_create_")) {
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.YELLOW)
          .setTitle("Setup Cancelled")
          .setDescription(
            "Server creation has been cancelled. Type `!setup` to start again or `!modify` to make specific changes."
          ),
      ],
    });
    return;
  }

  // Ticket system buttons
  if (customId.startsWith("create_ticket_")) {
    await handleTicketCreation(interaction);
    return;
  }

  if (customId.startsWith("close_ticket_")) {
    await handleTicketClose(interaction);
    return;
  }

  // Welcome configuration button
  if (customId.startsWith("welcome_configure_")) {
    const guildId = customId.replace("welcome_configure_", "");
    const guild = interaction.guild;
    if (!guild) return;

    // Build channel select for welcome channel
    const textChannels = guild.channels.cache
      .filter((ch) => ch.type === ChannelType.GuildText)
      .map((ch) => ({ label: ch.name, value: ch.id }))
      .slice(0, 25);

    const channelSelect = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`welcome_channel_${guildId}`)
        .setPlaceholder("Select welcome channel")
        .addOptions(textChannels)
    );

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.BLURPLE)
          .setTitle("Select Welcome Channel")
          .setDescription("Choose which channel should display welcome messages for new members."),
      ],
      components: [channelSelect],
      ephemeral: true,
    });
    return;
  }

  // Welcome disable button
  if (customId.startsWith("welcome_disable_")) {
    const guildId = customId.replace("welcome_disable_", "");
    welcomeConfigs.delete(guildId);

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.GREEN)
          .setTitle("Welcome System Disabled")
          .setDescription("Welcome messages and auto-roles have been turned off."),
      ],
      ephemeral: true,
    });
    return;
  }

  // Reaction roles create button
  if (customId.startsWith("rr_create_")) {
    const guildId = customId.replace("rr_create_", "");
    const guild = interaction.guild;
    if (!guild) return;

    // Get available roles (excluding @everyone and bot roles)
    const availableRoles = guild.roles.cache
      .filter((r) => r.name !== "@everyone" && !r.managed && r.position < guild.members.me!.roles.highest.position)
      .map((r) => ({ label: r.name, value: r.id }))
      .slice(0, 25);

    if (availableRoles.length === 0) {
      await interaction.reply({
        content: "No suitable roles found. Please create some roles first.",
        ephemeral: true,
      });
      return;
    }

    const roleSelect = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`rr_roles_${guildId}`)
        .setPlaceholder("Select roles for reaction roles")
        .setMinValues(1)
        .setMaxValues(Math.min(availableRoles.length, 10))
        .addOptions(availableRoles)
    );

    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.BLURPLE)
          .setTitle("Select Roles")
          .setDescription("Choose the roles you want members to be able to assign themselves through reactions."),
      ],
      components: [roleSelect],
      ephemeral: true,
    });
    return;
  }

  // Reaction roles view button
  if (customId.startsWith("rr_view_")) {
    const guildId = customId.replace("rr_view_", "");
    const configs = reactionRoleConfigs.get(guildId) || [];

    if (configs.length === 0) {
      await interaction.reply({
        content: "No reaction roles configured yet.",
        ephemeral: true,
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(COLORS.BLURPLE)
      .setTitle("Active Reaction Roles")
      .setDescription(
        configs.map((c) => `${c.emoji} - ${c.roleName} (in <#${c.channelId}>)`).join("\n")
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // Template use confirmation
  if (customId.startsWith("use_template_")) {
    const parts = customId.split("_");
    const templateKey = parts[2];
    const guildId = parts[3];
    const userId = parts[4];

    const template = SERVER_TEMPLATES[templateKey as keyof typeof SERVER_TEMPLATES];
    if (!template) {
      await interaction.reply({ content: "Template not found.", ephemeral: true });
      return;
    }

    const sessionId = `${guildId}-${userId}`;
    activeSessions.set(sessionId, {
      guildId,
      userId,
      channelId: interaction.channel!.id,
      responses: template.responses as Partial<QuestionnaireResponses>,
      currentQuestion: QUESTIONS.length, // Skip to end
    });

    // Generate design and show preview
    await interaction.deferReply();

    try {
      const design = await generateServerDesign(template.responses as QuestionnaireResponses);
      activeSessions.get(sessionId)!.design = design;

      await showServerPreview(interaction.channel as TextChannel, sessionId, design);
      await interaction.deleteReply();
    } catch (error) {
      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(COLORS.RED)
            .setTitle("Error")
            .setDescription(`Failed to generate design: ${error instanceof Error ? error.message : "Unknown error"}`),
        ],
      });
    }
    return;
  }
}

async function handleSelectInteraction(interaction: StringSelectMenuInteraction) {
  const customId = interaction.customId;
  const values = interaction.values;

  if (customId.startsWith("select_")) {
    const parts = customId.split("_");
    const questionId = parts[1];
    const sessionId = parts.slice(2).join("_");

    await processAnswer(interaction, sessionId, questionId, values[0]);
  } else if (customId.startsWith("multiselect_")) {
    const parts = customId.split("_");
    const questionId = parts[1];
    const sessionId = parts.slice(2).join("_");

    await processAnswer(interaction, sessionId, questionId, values);
  } else if (customId.startsWith("ticket_type_")) {
    await handleTicketTypeSelection(interaction);
  } else if (customId.startsWith("template_select_")) {
    // Template selection
    const parts = customId.split("_");
    const guildId = parts[2];
    const userId = parts[3];
    const templateKey = values[0];

    const template = SERVER_TEMPLATES[templateKey as keyof typeof SERVER_TEMPLATES];
    if (!template) {
      await interaction.reply({ content: "Template not found.", ephemeral: true });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(COLORS.BLURPLE)
      .setTitle(`Template: ${template.name}`)
      .setDescription(template.description)
      .addFields(
        { name: "Theme", value: template.responses.designTheme, inline: true },
        { name: "Moderation", value: template.responses.moderationLevel, inline: true },
        { name: "Activities", value: template.responses.primaryActivities.join(", "), inline: false },
        { name: "Channels", value: template.responses.channelTypes.join(", "), inline: false },
        { name: "Role Structure", value: template.responses.roleHierarchy, inline: false }
      )
      .setFooter({ text: "Click 'Use Template' to generate server design" });

    const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`use_template_${templateKey}_${guildId}_${userId}`)
        .setLabel("Use Template")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId("template_cancel")
        .setLabel("Cancel")
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.update({ embeds: [embed], components: [buttons] });
  } else if (customId.startsWith("welcome_channel_")) {
    // Welcome channel selection
    const guildId = customId.replace("welcome_channel_", "");
    const channelId = values[0];
    const guild = interaction.guild;
    if (!guild) return;

    // Get available roles for auto-role
    const availableRoles = guild.roles.cache
      .filter((r) => r.name !== "@everyone" && !r.managed && r.position < guild.members.me!.roles.highest.position)
      .map((r) => ({ label: r.name, value: r.id }))
      .slice(0, 25);

    // Store partial config
    welcomeConfigs.set(guildId, {
      channelId,
      message: "Welcome {user} to {server}! We're glad to have you here.",
    });

    const roleSelect = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`welcome_autorole_${guildId}`)
        .setPlaceholder("Select auto-role (optional)")
        .addOptions([
          { label: "No auto-role", value: "none" },
          ...availableRoles,
        ])
    );

    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.BLURPLE)
          .setTitle("Select Auto-Role (Optional)")
          .setDescription("Choose a role to automatically assign to new members, or skip this step."),
      ],
      components: [roleSelect],
    });
  } else if (customId.startsWith("welcome_autorole_")) {
    // Auto-role selection
    const guildId = customId.replace("welcome_autorole_", "");
    const roleId = values[0];
    const guild = interaction.guild;
    if (!guild) return;

    const config = welcomeConfigs.get(guildId);
    if (!config) {
      await interaction.reply({ content: "Configuration error. Please start again.", ephemeral: true });
      return;
    }

    if (roleId !== "none") {
      const role = guild.roles.cache.get(roleId);
      config.autoRoleId = roleId;
      config.autoRoleName = role?.name;
    }

    welcomeConfigs.set(guildId, config);

    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.GREEN)
          .setTitle("Welcome System Configured")
          .setDescription(
            `Welcome messages will be sent to <#${config.channelId}>\n` +
            (config.autoRoleName ? `Auto-role: **${config.autoRoleName}**` : "No auto-role configured")
          )
          .addFields({
            name: "Default Message",
            value: config.message,
          }),
      ],
      components: [],
    });
  } else if (customId.startsWith("rr_roles_")) {
    // Reaction role selection
    const guildId = customId.replace("rr_roles_", "");
    const roleIds = values;
    const guild = interaction.guild;
    if (!guild) return;

    // Store selected roles temporarily and create the reaction role message
    const roles = roleIds.map((id) => guild.roles.cache.get(id)!).filter(Boolean);

    // Default emojis for roles
    const defaultEmojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"];

    const embed = new EmbedBuilder()
      .setColor(COLORS.BLURPLE)
      .setTitle("Role Selection")
      .setDescription("React with the corresponding emoji to get a role!")
      .addFields(
        roles.map((role, i) => ({
          name: defaultEmojis[i] || `${i + 1}`,
          value: `<@&${role.id}>`,
          inline: true,
        }))
      )
      .setFooter({ text: "Reactions are toggleable - react again to remove the role" });

    // Send the message in the current channel
    const message = await (interaction.channel as TextChannel).send({ embeds: [embed] });

    // Add reactions
    for (let i = 0; i < roles.length; i++) {
      await message.react(defaultEmojis[i] || `${i + 1}`);
    }

    // Store configs
    const configs: ReactionRoleConfig[] = roles.map((role, i) => ({
      messageId: message.id,
      channelId: interaction.channel!.id,
      emoji: defaultEmojis[i] || `${i + 1}`,
      roleId: role.id,
      roleName: role.name,
    }));

    reactionRoleConfigs.set(guildId, [
      ...(reactionRoleConfigs.get(guildId) || []),
      ...configs,
    ]);

    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.GREEN)
          .setTitle("Reaction Roles Created")
          .setDescription(
            `Reaction role message created with ${roles.length} roles.\n` +
            roles.map((r, i) => `${defaultEmojis[i]} - ${r.name}`).join("\n")
          ),
      ],
      components: [],
    });
  }
}

async function handleModalSubmit(interaction: ModalSubmitInteraction) {
  const customId = interaction.customId;

  if (customId.startsWith("modal_")) {
    const parts = customId.split("_");
    const questionId = parts[1];
    const sessionId = parts.slice(2).join("_");
    const response = interaction.fields.getTextInputValue("response");

    await processAnswer(interaction, sessionId, questionId, response);
  } else if (customId.startsWith("modify_modal_")) {
    const sessionId = customId.replace("modify_modal_", "");
    const request = interaction.fields.getTextInputValue("modification_request");
    await processModificationFromModal(interaction, sessionId, request);
  }
}

async function processAnswer(
  interaction: ButtonInteraction | StringSelectMenuInteraction | ModalSubmitInteraction,
  sessionId: string,
  questionId: string,
  value: string | string[]
) {
  const session = activeSessions.get(sessionId);
  if (!session) {
    await interaction.reply({
      content: "Session expired. Please start again with `!setup`",
      ephemeral: true,
    });
    return;
  }

  // Map question ID to response field
  const responseMap: Record<string, keyof QuestionnaireResponses> = {
    purpose: "serverPurpose",
    audience: "targetAudience",
    size: "communitySize",
    activities: "primaryActivities",
    channels: "channelTypes",
    roles: "roleHierarchy",
    moderation: "moderationLevel",
    theme: "designTheme",
    colors: "colorPreferences",
    emojis: "emojiStyle",
    naming: "namingStyle",
    tickets: "ticketSystemNeeded",
    features: "specialFeatures",
    access: "accessLevels",
    notes: "additionalNotes",
  };

  const responseKey = responseMap[questionId];
  if (responseKey) {
    if (responseKey === "ticketSystemNeeded") {
      (session.responses as any)[responseKey] = value === "yes";
    } else if (Array.isArray(value)) {
      (session.responses as any)[responseKey] = value;
    } else {
      (session.responses as any)[responseKey] = value;
    }
  }

  session.currentQuestion++;

  await interaction.deferUpdate();

  // Check if we've completed all questions
  if (session.currentQuestion >= QUESTIONS.length) {
    await generateAndShowPreview(interaction.channel as TextChannel, sessionId);
  } else {
    await sendQuestion(interaction.channel as TextChannel, sessionId, session.currentQuestion);
  }
}

async function generateAndShowPreview(channel: TextChannel, sessionId: string) {
  const session = activeSessions.get(sessionId);
  if (!session) return;

  // Send generating message
  const loadingEmbed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Generating Your Server Design...")
    .setDescription(
      "Our AI is analyzing your responses and creating a custom server structure. This may take a moment..."
    );

  const loadingMsg = await channel.send({ embeds: [loadingEmbed] });

  try {
    // Fill in default values for any missing responses
    const responses: QuestionnaireResponses = {
      serverPurpose: session.responses.serverPurpose || "General community",
      targetAudience: session.responses.targetAudience || "general",
      communitySize: session.responses.communitySize || "medium",
      primaryActivities: session.responses.primaryActivities || ["chat"],
      channelTypes: session.responses.channelTypes || ["welcome", "general", "announcements"],
      roleHierarchy: session.responses.roleHierarchy || "Owner, Moderators, Members",
      moderationLevel: session.responses.moderationLevel || "moderate",
      designTheme: session.responses.designTheme || "community",
      colorPreferences: session.responses.colorPreferences || "Blue theme",
      emojiStyle: session.responses.emojiStyle || "unicode",
      namingStyle: session.responses.namingStyle || "lowercase",
      ticketSystemNeeded: session.responses.ticketSystemNeeded ?? false,
      specialFeatures: session.responses.specialFeatures || [],
      accessLevels: session.responses.accessLevels || "open",
      additionalNotes: session.responses.additionalNotes || "",
    };

    // Generate server design using Gemini
    const design = await generateServerDesign(responses);
    session.design = design;

    // Delete loading message
    await loadingMsg.delete();

    // Show comprehensive preview
    await showServerPreview(channel, sessionId, design);
  } catch (error) {
    console.error("Design generation error:", error);
    await loadingMsg.edit({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.RED)
          .setTitle("Design Generation Failed")
          .setDescription(
            "An error occurred while generating your server design. Please try again with `!setup`."
          ),
      ],
    });
  }
}

async function showServerPreview(channel: TextChannel, sessionId: string, design: ServerDesign) {
  // Create main overview embed
  const overviewEmbed = new EmbedBuilder()
    .setColor(COLORS.GREEN)
    .setTitle(`Server Preview: ${design.serverName}`)
    .setDescription(design.description)
    .addFields(
      {
        name: "Design Theme",
        value: `**Style:** ${design.theme.style}\n**Naming:** ${design.theme.namingConvention}\n**Emojis:** ${design.theme.emojiStyle}`,
        inline: true,
      },
      {
        name: "Color Palette",
        value: design.theme.colorScheme.slice(0, 5).join(", "),
        inline: true,
      }
    );

  // Create roles embed
  const rolesText = design.roles
    .sort((a, b) => b.position - a.position)
    .map((role) => `${role.color} **${role.name}** - ${role.description}`)
    .join("\n");

  const rolesEmbed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Roles")
    .setDescription(rolesText || "No custom roles configured");

  // Create categories/channels embed
  const categoriesEmbed = new EmbedBuilder().setColor(COLORS.BLURPLE).setTitle("Categories & Channels");

  let channelsList = "";
  for (const category of design.categories.sort((a, b) => a.position - b.position)) {
    channelsList += `\n**${category.emoji || ""} ${category.name}**\n`;
    for (const ch of category.channels.sort((a, b) => a.position - b.position)) {
      const icon = ch.type === "voice" ? "🔊" : ch.type === "announcement" ? "📢" : "#";
      const permissions =
        ch.permissions.length > 0
          ? ` (${ch.permissions.map((p) => p.role).join(", ")})`
          : "";
      channelsList += `  ${ch.emoji || icon} ${ch.name}${permissions}\n`;
    }
  }

  categoriesEmbed.setDescription(channelsList.slice(0, 4000) || "No categories configured");

  // Create features embed
  const featuresEmbed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Features & Systems");

  const features: string[] = [];
  if (design.ticketSystem?.enabled) {
    features.push(
      `**Ticket System:** ${design.ticketSystem.ticketTypes.join(", ")}`
    );
  }
  if (design.moderationTools.enabled) {
    const modFeatures: string[] = [];
    if (design.moderationTools.logChannel) modFeatures.push("Logging");
    if (design.moderationTools.modDiscussion) modFeatures.push("Staff Discussion");
    if (design.moderationTools.reportsChannel) modFeatures.push("Reports");
    features.push(`**Moderation:** ${modFeatures.join(", ")}`);
  }

  featuresEmbed.setDescription(features.join("\n") || "No special features configured");

  // Create confirmation buttons
  const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`confirm_create_${sessionId}`)
      .setLabel("Create Server")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`cancel_create_${sessionId}`)
      .setLabel("Cancel")
      .setStyle(ButtonStyle.Danger)
  );

  await channel.send({
    embeds: [overviewEmbed, rolesEmbed, categoriesEmbed, featuresEmbed],
    components: [buttons],
  });
}

async function executeServerCreation(interaction: ButtonInteraction, sessionId: string) {
  const session = activeSessions.get(sessionId);
  if (!session || !session.design) {
    await interaction.reply({
      content: "Session expired. Please start again with `!setup`",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply();

  const guild = interaction.guild;
  if (!guild) return;

  const design = session.design;

  try {
    // Progress updates
    const progressEmbed = new EmbedBuilder()
      .setColor(COLORS.BLURPLE)
      .setTitle("Creating Your Server...")
      .setDescription("Please wait while I set up your server...");

    const progressMsg = await interaction.editReply({ embeds: [progressEmbed] });

    // Step 1: Clean up default channels
    await updateProgress(progressMsg, "Cleaning up default channels...", 10);
    await cleanupDefaultChannels(guild);

    // Step 2: Create roles
    await updateProgress(progressMsg, "Creating roles...", 25);
    const roleMap = await createRoles(guild, design.roles);

    // Step 3: Create categories and channels
    await updateProgress(progressMsg, "Creating categories and channels...", 50);
    await createCategoriesAndChannels(guild, design.categories, roleMap);

    // Step 4: Set up ticket system if enabled
    if (design.ticketSystem?.enabled) {
      await updateProgress(progressMsg, "Setting up ticket system...", 75);
      await setupTicketSystem(guild, design.ticketSystem, roleMap);
    }

    // Step 5: Set up moderation tools
    if (design.moderationTools.enabled) {
      await updateProgress(progressMsg, "Setting up moderation tools...", 90);
      await setupModerationTools(guild, design.moderationTools, roleMap);
    }

    // Done!
    await updateProgress(progressMsg, "Server setup complete!", 100);

    const successEmbed = new EmbedBuilder()
      .setColor(COLORS.GREEN)
      .setTitle("Server Setup Complete!")
      .setDescription(
        `Your server has been successfully configured with the **${design.theme.style}** theme.\n\nUse \`!modify <request>\` to make changes using natural language.`
      )
      .addFields(
        { name: "Roles Created", value: String(design.roles.length), inline: true },
        { name: "Categories", value: String(design.categories.length), inline: true },
        {
          name: "Channels",
          value: String(design.categories.reduce((acc, cat) => acc + cat.channels.length, 0)),
          inline: true,
        }
      );

    await interaction.editReply({ embeds: [successEmbed] });

    // Clean up session
    activeSessions.delete(sessionId);
  } catch (error) {
    console.error("Server creation error:", error);
    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.RED)
          .setTitle("Setup Failed")
          .setDescription(
            `An error occurred: ${error instanceof Error ? error.message : "Unknown error"}\n\nPlease check my permissions and try again.`
          ),
      ],
    });
  }
}

async function updateProgress(message: any, status: string, percent: number) {
  const progressBar = "█".repeat(Math.floor(percent / 10)) + "░".repeat(10 - Math.floor(percent / 10));

  const embed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Creating Your Server...")
    .setDescription(`${status}\n\n\`${progressBar}\` ${percent}%`);

  await message.edit({ embeds: [embed] });
}

async function cleanupDefaultChannels(guild: Guild) {
  // Get all existing channels
  const channels = guild.channels.cache;

  // Delete default channels (text-channels, general, etc.)
  for (const [, channel] of channels) {
    // Skip if it's a category with children or important channels
    if (
      channel.type === ChannelType.GuildCategory &&
      channels.some((ch) => ch.parentId === channel.id)
    ) {
      continue;
    }

    // Delete the channel
    try {
      await channel.delete("Server Builder: Cleaning up for new structure");
    } catch (error) {
      console.error(`Failed to delete channel ${channel.name}:`, error);
    }
  }
}

async function createRoles(guild: Guild, roles: RoleConfig[]): Promise<Map<string, string>> {
  const roleMap = new Map<string, string>();

  // Sort roles by position (highest first for proper hierarchy)
  const sortedRoles = roles.sort((a, b) => b.position - a.position);

  for (const roleConfig of sortedRoles) {
    try {
      // Parse permissions
      let permissions: bigint = BigInt(0);
      for (const perm of roleConfig.permissions) {
        const permBit = PERMISSION_MAP[perm];
        if (permBit) {
          permissions |= permBit;
        }
      }

      const role = await guild.roles.create({
        name: roleConfig.name,
        color: roleConfig.color as ColorResolvable,
        permissions: permissions,
        mentionable: roleConfig.mentionable,
        hoist: roleConfig.hoist,
        reason: "Server Builder: Creating role structure",
      });

      roleMap.set(roleConfig.name, role.id);
    } catch (error) {
      console.error(`Failed to create role ${roleConfig.name}:`, error);
    }
  }

  return roleMap;
}

async function createCategoriesAndChannels(
  guild: Guild,
  categories: CategoryConfig[],
  roleMap: Map<string, string>
) {
  // Sort categories by position
  const sortedCategories = categories.sort((a, b) => a.position - b.position);

  for (const categoryConfig of sortedCategories) {
    try {
      // Create category
      const category = await guild.channels.create({
        name: categoryConfig.emoji
          ? `${categoryConfig.emoji} ${categoryConfig.name}`
          : categoryConfig.name,
        type: ChannelType.GuildCategory,
        position: categoryConfig.position,
        reason: "Server Builder: Creating category structure",
      });

      // Create channels within the category
      const sortedChannels = categoryConfig.channels.sort((a, b) => a.position - b.position);

      for (const channelConfig of sortedChannels) {
        await createChannel(guild, channelConfig, category.id, roleMap);
      }
    } catch (error) {
      console.error(`Failed to create category ${categoryConfig.name}:`, error);
    }
  }
}

async function createChannel(
  guild: Guild,
  config: ChannelConfig,
  parentId: string,
  roleMap: Map<string, string>
) {
  try {
    // Map channel type
    let channelType: ChannelType;
    switch (config.type) {
      case "voice":
        channelType = ChannelType.GuildVoice;
        break;
      case "announcement":
        channelType = ChannelType.GuildAnnouncement;
        break;
      case "forum":
        channelType = ChannelType.GuildForum;
        break;
      case "stage":
        channelType = ChannelType.GuildStageVoice;
        break;
      default:
        channelType = ChannelType.GuildText;
    }

    // Build permission overwrites
    const permissionOverwrites: any[] = [];

    for (const perm of config.permissions) {
      const roleId = roleMap.get(perm.role) || guild.roles.everyone.id;

      let allow: bigint = BigInt(0);
      let deny: bigint = BigInt(0);

      for (const p of perm.allow) {
        const bit = PERMISSION_MAP[p];
        if (bit) allow |= bit;
      }

      for (const p of perm.deny) {
        const bit = PERMISSION_MAP[p];
        if (bit) deny |= bit;
      }

      permissionOverwrites.push({
        id: roleId,
        allow: allow,
        deny: deny,
      });
    }

    const channelName = config.emoji ? `${config.emoji}${config.name}` : config.name;

    const channelOptions: any = {
      name: channelName,
      type: channelType,
      parent: parentId,
      position: config.position,
      topic: config.topic,
      permissionOverwrites,
      reason: "Server Builder: Creating channel",
    };

    if (config.slowmode && channelType === ChannelType.GuildText) {
      channelOptions.rateLimitPerUser = config.slowmode;
    }

    if (config.nsfw !== undefined && channelType === ChannelType.GuildText) {
      channelOptions.nsfw = config.nsfw;
    }

    await guild.channels.create(channelOptions);
  } catch (error) {
    console.error(`Failed to create channel ${config.name}:`, error);
  }
}

async function setupTicketSystem(
  guild: Guild,
  config: any,
  roleMap: Map<string, string>
) {
  try {
    // Create ticket category
    const ticketCategory = await guild.channels.create({
      name: config.categoryName || "Support",
      type: ChannelType.GuildCategory,
      reason: "Server Builder: Setting up ticket system",
    });

    // Create ticket creation channel
    const ticketChannel = await guild.channels.create({
      name: "create-ticket",
      type: ChannelType.GuildText,
      parent: ticketCategory.id,
      topic: "Click the button below to create a support ticket",
      reason: "Server Builder: Ticket creation channel",
    });

    // Send ticket creation embed
    const ticketEmbed = new EmbedBuilder()
      .setColor(COLORS.BLURPLE)
      .setTitle("Support Tickets")
      .setDescription(
        config.welcomeMessage ||
          "Need help? Click the button below to create a private support ticket."
      )
      .addFields({
        name: "Available Support Types",
        value: config.ticketTypes?.join("\n") || "General Support",
      });

    const ticketButton = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("create_ticket_new")
        .setLabel("Create Ticket")
        .setStyle(ButtonStyle.Primary)
    );

    await ticketChannel.send({ embeds: [ticketEmbed], components: [ticketButton] });
  } catch (error) {
    console.error("Failed to set up ticket system:", error);
  }
}

async function setupModerationTools(
  guild: Guild,
  config: ModerationConfig,
  roleMap: Map<string, string>
) {
  try {
    // Create moderation category (hidden from regular members)
    const modCategory = await guild.channels.create({
      name: "Staff Area",
      type: ChannelType.GuildCategory,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
      ],
      reason: "Server Builder: Setting up moderation area",
    });

    // Create mod channels
    if (config.logChannel) {
      await guild.channels.create({
        name: "mod-logs",
        type: ChannelType.GuildText,
        parent: modCategory.id,
        topic: "Automatic logging of moderation actions",
        reason: "Server Builder: Mod logs channel",
      });
    }

    if (config.modDiscussion) {
      await guild.channels.create({
        name: "mod-discussion",
        type: ChannelType.GuildText,
        parent: modCategory.id,
        topic: "Private staff discussion channel",
        reason: "Server Builder: Mod discussion channel",
      });
    }

    if (config.reportsChannel) {
      await guild.channels.create({
        name: "reports",
        type: ChannelType.GuildText,
        parent: modCategory.id,
        topic: "Member reports and concerns",
        reason: "Server Builder: Reports channel",
      });
    }
  } catch (error) {
    console.error("Failed to set up moderation tools:", error);
  }
}

async function handleTicketCreation(interaction: ButtonInteraction) {
  const guild = interaction.guild;
  if (!guild) return;

  try {
    // Find the ticket category
    const ticketCategory = guild.channels.cache.find(
      (ch) => ch.type === ChannelType.GuildCategory && ch.name.toLowerCase().includes("support")
    );

    if (!ticketCategory) {
      await interaction.reply({
        content: "Ticket system not properly configured.",
        ephemeral: true,
      });
      return;
    }

    // Create ticket channel
    const ticketNumber = Math.floor(Math.random() * 10000);
    const ticketChannel = await guild.channels.create({
      name: `ticket-${interaction.user.username}-${ticketNumber}`,
      type: ChannelType.GuildText,
      parent: ticketCategory.id,
      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: interaction.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        },
      ],
      reason: `Ticket created by ${interaction.user.tag}`,
    });

    // Send welcome message in ticket
    const ticketEmbed = new EmbedBuilder()
      .setColor(COLORS.GREEN)
      .setTitle("Support Ticket")
      .setDescription(
        `Welcome ${interaction.user}! A staff member will assist you shortly.\n\nPlease describe your issue or question below.`
      )
      .setTimestamp();

    const closeButton = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`close_ticket_${ticketChannel.id}`)
        .setLabel("Close Ticket")
        .setStyle(ButtonStyle.Danger)
    );

    await ticketChannel.send({ embeds: [ticketEmbed], components: [closeButton] });

    await interaction.reply({
      content: `Your ticket has been created: ${ticketChannel}`,
      ephemeral: true,
    });
  } catch (error) {
    console.error("Ticket creation error:", error);
    await interaction.reply({
      content: "Failed to create ticket. Please try again.",
      ephemeral: true,
    });
  }
}

async function handleTicketClose(interaction: ButtonInteraction) {
  const channel = interaction.channel as TextChannel;

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.YELLOW)
        .setTitle("Closing Ticket")
        .setDescription("This ticket will be deleted in 5 seconds..."),
    ],
  });

  setTimeout(async () => {
    try {
      await channel.delete("Ticket closed");
    } catch (error) {
      console.error("Failed to delete ticket channel:", error);
    }
  }, 5000);
}

async function handleTicketTypeSelection(interaction: StringSelectMenuInteraction) {
  // Handle specific ticket type selection if needed
  await interaction.deferUpdate();
}

async function handleModificationRequest(message: Message, request: string) {
  if (!message.guild) return;

  const member = message.member as GuildMember;
  if (!member.permissions.has(PermissionFlagsBits.Administrator)) {
    await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.RED)
          .setTitle("Permission Denied")
          .setDescription("You need Administrator permissions to modify the server."),
      ],
    });
    return;
  }

  const loadingEmbed = new EmbedBuilder()
    .setColor(COLORS.BLURPLE)
    .setTitle("Processing Modification...")
    .setDescription(`Analyzing your request: "${request}"`);

  const loadingMsg = await message.reply({ embeds: [loadingEmbed] });

  try {
    // Build a simplified current design from the guild
    const currentDesign = await buildCurrentDesign(message.guild);

    // Process the modification request with Gemini
    const result = await processModificationRequest(currentDesign, request);

    // Show the planned changes
    const changesEmbed = new EmbedBuilder()
      .setColor(COLORS.YELLOW)
      .setTitle("Proposed Changes")
      .setDescription(result.explanation)
      .addFields({
        name: "Changes to Apply",
        value:
          result.changes.map((c) => `- **${c.type}**: ${c.target}`).join("\n") ||
          "No changes identified",
      });

    const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`apply_changes_${message.id}`)
        .setLabel("Apply Changes")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`cancel_changes_${message.id}`)
        .setLabel("Cancel")
        .setStyle(ButtonStyle.Secondary)
    );

    await loadingMsg.edit({ embeds: [changesEmbed], components: [buttons] });

    // Store the changes for application
    // (In a production app, you'd store this properly)
  } catch (error) {
    console.error("Modification error:", error);
    await loadingMsg.edit({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.RED)
          .setTitle("Modification Failed")
          .setDescription(
            `Could not process your request: ${error instanceof Error ? error.message : "Unknown error"}`
          ),
      ],
    });
  }
}

async function buildCurrentDesign(guild: Guild): Promise<ServerDesign> {
  // Build a representation of the current server structure
  const categories: CategoryConfig[] = [];

  for (const [, channel] of guild.channels.cache) {
    if (channel.type === ChannelType.GuildCategory) {
      const children = guild.channels.cache.filter((ch) => ch.parentId === channel.id);

      const channelConfigs: ChannelConfig[] = [];
      for (const [, child] of children) {
        let type: "text" | "voice" | "announcement" | "forum" | "stage" = "text";
        if (child.type === ChannelType.GuildVoice) type = "voice";
        if (child.type === ChannelType.GuildAnnouncement) type = "announcement";
        if (child.type === ChannelType.GuildForum) type = "forum";
        if (child.type === ChannelType.GuildStageVoice) type = "stage";

        channelConfigs.push({
          name: child.name,
          type,
          topic: (child as TextChannel).topic || "",
          position: child.position,
          permissions: [],
        });
      }

      categories.push({
        name: channel.name,
        position: channel.position,
        channels: channelConfigs,
        permissions: [],
      });
    }
  }

  const roles: RoleConfig[] = guild.roles.cache
    .filter((r) => r.name !== "@everyone")
    .map((r) => ({
      name: r.name,
      color: r.hexColor,
      permissions: [],
      position: r.position,
      mentionable: r.mentionable,
      hoist: r.hoist,
      description: "",
    }));

  return {
    serverName: guild.name,
    description: guild.description || "",
    theme: {
      style: "custom",
      colorScheme: [],
      emojiStyle: "unicode",
      namingConvention: "lowercase",
    },
    roles,
    categories,
    ticketSystem: null,
    moderationTools: {
      enabled: false,
      logChannel: false,
      modDiscussion: false,
      reportsChannel: false,
      automod: false,
    },
  };
}

async function processModificationFromModal(
  interaction: ModalSubmitInteraction,
  sessionId: string,
  request: string
) {
  // Similar to handleModificationRequest but from modal
  await interaction.deferReply();
  // ... implementation
}

async function showCurrentPreview(message: Message) {
  if (!message.guild) return;

  const sessionId = `${message.guild.id}-${message.author.id}`;
  const session = activeSessions.get(sessionId);

  if (!session?.design) {
    await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.YELLOW)
          .setTitle("No Active Design")
          .setDescription(
            "There's no pending server design to preview. Use `!setup` to start creating one."
          ),
      ],
    });
    return;
  }

  await showServerPreview(message.channel as TextChannel, sessionId, session.design);
}

export { activeSessions, COLORS };

