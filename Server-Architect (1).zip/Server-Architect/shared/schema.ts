import { z } from "zod";

// Bot status types
export const botStatusSchema = z.object({
  status: z.enum(["offline", "connecting", "online", "error"]),
  error: z.string().nullable(),
  guilds: z.number(),
  username: z.string().nullable(),
});

export type BotStatus = z.infer<typeof botStatusSchema>;

// Guild info
export const guildSchema = z.object({
  id: z.string(),
  name: z.string(),
  memberCount: z.number(),
  icon: z.string().nullable(),
});

export type Guild = z.infer<typeof guildSchema>;

// Invite response
export const inviteResponseSchema = z.object({
  inviteUrl: z.string().nullable(),
});

export type InviteResponse = z.infer<typeof inviteResponseSchema>;
