import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Bot, 
  Server, 
  Users, 
  ExternalLink, 
  CheckCircle2, 
  XCircle, 
  Loader2,
  Sparkles,
  Shield,
  MessageSquare,
  Settings,
  Palette,
  Ticket
} from "lucide-react";
import { SiDiscord } from "react-icons/si";
import type { BotStatus, Guild } from "@shared/schema";

export default function Home() {
  const { data: status, isLoading: statusLoading } = useQuery<BotStatus>({
    queryKey: ["/api/status"],
    refetchInterval: 5000,
  });

  const { data: inviteData } = useQuery<{ inviteUrl: string | null }>({
    queryKey: ["/api/invite"],
    enabled: status?.status === "online",
  });

  const { data: guildsData } = useQuery<{ guilds: Guild[] }>({
    queryKey: ["/api/guilds"],
    enabled: status?.status === "online",
    refetchInterval: 30000,
  });

  const getStatusBadge = () => {
    if (statusLoading) {
      return <Badge variant="secondary"><Loader2 className="w-3 h-3 mr-1 animate-spin" />Loading</Badge>;
    }

    switch (status?.status) {
      case "online":
        return <Badge className="bg-green-600 text-white"><CheckCircle2 className="w-3 h-3 mr-1" />Online</Badge>;
      case "connecting":
        return <Badge variant="secondary"><Loader2 className="w-3 h-3 mr-1 animate-spin" />Connecting</Badge>;
      case "error":
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Error</Badge>;
      default:
        return <Badge variant="secondary">Offline</Badge>;
    }
  };

  const features = [
    {
      icon: MessageSquare,
      title: "Deep Questionnaire",
      description: "15+ questions to understand your perfect server structure"
    },
    {
      icon: Sparkles,
      title: "AI-Powered Design",
      description: "Gemini AI creates intelligent channel and role configurations"
    },
    {
      icon: Palette,
      title: "Custom Theming",
      description: "Choose your color scheme, emoji style, and naming conventions"
    },
    {
      icon: Shield,
      title: "Smart Permissions",
      description: "Automatic permission setup based on channel purpose"
    },
    {
      icon: Ticket,
      title: "Ticket System",
      description: "Built-in support ticket creation and management"
    },
    {
      icon: Settings,
      title: "Post-Creation Edits",
      description: "Modify your server anytime using natural language"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-b from-primary/10 via-background to-background">
        <div className="absolute inset-0 bg-grid-white/10 [mask-image:radial-gradient(ellipse_at_center,transparent_20%,black)]" />
        <div className="relative max-w-6xl mx-auto px-4 py-16 sm:py-24">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 blur-xl bg-primary/30 rounded-full" />
                <div className="relative bg-card border border-card-border rounded-full p-4">
                  <Bot className="w-12 h-12 text-primary" />
                </div>
              </div>
            </div>
            
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4">
              Discord Server Builder
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Create professional, fully-configured Discord servers with AI-powered design. 
              Just answer a few questions and watch your perfect server come to life.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              {status?.status === "online" && inviteData?.inviteUrl && (
                <Button size="lg" asChild>
                  <a href={inviteData.inviteUrl} target="_blank" rel="noopener noreferrer" data-testid="button-invite-bot">
                    <SiDiscord className="w-5 h-5 mr-2" />
                    Add to Discord
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </Button>
              )}
              <div className="flex items-center gap-2">
                {getStatusBadge()}
                {status?.username && (
                  <span className="text-sm text-muted-foreground" data-testid="text-bot-username">
                    {status.username}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Status Card */}
      <div className="max-w-6xl mx-auto px-4 -mt-8 relative z-10">
        <Card className="border-card-border">
          <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Server className="w-5 h-5" />
                Bot Status
              </CardTitle>
              <CardDescription>Current connection and server information</CardDescription>
            </div>
            {getStatusBadge()}
          </CardHeader>
          <CardContent>
            {statusLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Skeleton className="h-20" />
                <Skeleton className="h-20" />
                <Skeleton className="h-20" />
              </div>
            ) : status?.status === "error" ? (
              <div className="bg-destructive/10 border border-destructive/20 rounded-md p-4">
                <p className="text-sm text-destructive" data-testid="text-error-message">{status.error}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-muted/50 rounded-md p-4">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Server className="w-4 h-4" />
                    <span className="text-sm">Servers</span>
                  </div>
                  <p className="text-2xl font-bold" data-testid="text-guild-count">{status?.guilds || 0}</p>
                </div>
                <div className="bg-muted/50 rounded-md p-4">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Bot className="w-4 h-4" />
                    <span className="text-sm">Bot User</span>
                  </div>
                  <p className="text-lg font-medium truncate" data-testid="text-bot-name">
                    {status?.username || "Not connected"}
                  </p>
                </div>
                <div className="bg-muted/50 rounded-md p-4">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <CheckCircle2 className="w-4 h-4" />
                    <span className="text-sm">Status</span>
                  </div>
                  <p className="text-lg font-medium capitalize" data-testid="text-status">
                    {status?.status || "Unknown"}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Connected Servers */}
      {status?.status === "online" && guildsData?.guilds && guildsData.guilds.length > 0 && (
        <div className="max-w-6xl mx-auto px-4 mt-8">
          <Card className="border-card-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Connected Servers
              </CardTitle>
              <CardDescription>Servers where the bot is currently active</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {guildsData.guilds.map((guild) => (
                  <div
                    key={guild.id}
                    className="flex items-center gap-3 p-3 bg-muted/50 rounded-md"
                    data-testid={`card-guild-${guild.id}`}
                  >
                    {guild.icon ? (
                      <img
                        src={guild.icon}
                        alt={guild.name}
                        className="w-10 h-10 rounded-full"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                        <Server className="w-5 h-5 text-primary" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{guild.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {guild.memberCount.toLocaleString()} members
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Features */}
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Powerful Features</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Everything you need to create the perfect Discord server, powered by AI
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-card-border hover-elevate">
              <CardHeader>
                <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center mb-2">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <CardTitle className="text-lg">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* How It Works */}
      <div className="bg-muted/30 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How It Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Get your professional server set up in minutes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: 1, title: "Invite the Bot", description: "Add the bot to your Discord server" },
              { step: 2, title: "Run !setup", description: "Start the interactive questionnaire" },
              { step: 3, title: "Answer Questions", description: "Tell us about your ideal server" },
              { step: 4, title: "Watch the Magic", description: "AI creates your perfect server" },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {item.step}
                </div>
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Commands Reference */}
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Bot Commands</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Simple commands to control your server setup
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { command: "!setup", description: "Start the server setup questionnaire" },
            { command: "!modify <request>", description: "Make changes using natural language" },
            { command: "!preview", description: "View the pending server design" },
            { command: "!help", description: "Show help information" },
          ].map((cmd, index) => (
            <Card key={index} className="border-card-border">
              <CardContent className="pt-4">
                <code className="text-primary font-mono text-sm bg-primary/10 px-2 py-1 rounded">
                  {cmd.command}
                </code>
                <p className="text-sm text-muted-foreground mt-2">{cmd.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="max-w-6xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>Discord Server Builder Bot - Powered by Gemini AI</p>
        </div>
      </footer>
    </div>
  );
}
